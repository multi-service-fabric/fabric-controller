
@javax.xml.bind.annotation.XmlSchema(namespace = "http://mfc.msf/common/config/type/data", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package msf.mfc.common.config.type.data;
