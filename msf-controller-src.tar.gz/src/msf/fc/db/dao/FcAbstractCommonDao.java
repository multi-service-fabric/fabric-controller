package msf.fc.db.dao;

import msf.mfcfc.db.dao.AbstractCommonDao;


public abstract class FcAbstractCommonDao<E, K> extends AbstractCommonDao<E, K> {

}
