
package msf.mfcfc.failure.logicalif.data;

import msf.mfcfc.core.scenario.RestRequestBase;

public class LogicalIfStatusRequest extends RestRequestBase {

  public LogicalIfStatusRequest(String requestBody, String notificationAddress, String notificationPort) {
    super(requestBody, notificationAddress, notificationPort);
  }

}
