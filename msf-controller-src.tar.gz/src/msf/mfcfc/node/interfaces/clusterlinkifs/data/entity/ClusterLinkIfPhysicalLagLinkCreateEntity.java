
package msf.mfcfc.node.interfaces.clusterlinkifs.data.entity;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.SerializedName;

public class ClusterLinkIfPhysicalLagLinkCreateEntity {

  @SerializedName("node_id")
  private String nodeId;

  @SerializedName("lag_if_id")
  private String lagIfId;

  @SerializedName("opposite_node_id")
  private String oppositeNodeId;

  @SerializedName("opposite_lag_if_id")
  private String oppositeLagIfId;

  public String getNodeId() {
    return nodeId;
  }

  public void setNodeId(String nodeId) {
    this.nodeId = nodeId;
  }

  public String getLagIfId() {
    return lagIfId;
  }

  public void setLagIfId(String lagIfId) {
    this.lagIfId = lagIfId;
  }

  public String getOppositeNodeId() {
    return oppositeNodeId;
  }

  public void setOppositeNodeId(String oppositeNodeId) {
    this.oppositeNodeId = oppositeNodeId;
  }

  public String getOppositeLagIfId() {
    return oppositeLagIfId;
  }

  public void setOppositeLagIfId(String oppositeLagIfId) {
    this.oppositeLagIfId = oppositeLagIfId;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }
}
