
package msf.mfcfc.node.nodes.spines.data.entity;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.SerializedName;

import msf.mfcfc.node.interfaces.internalifs.data.entity.InternalLinkIfEntity;

public class SpineNodeEntity {

  @SerializedName("node_id")
  private String nodeId;

  @SerializedName("equipment_type_id")
  private String equipmentTypeId;

  @SerializedName("host_name")
  private String hostName;

  @SerializedName("mac_address")
  private String macAddress;

  @SerializedName("username")
  private String username;

  @SerializedName("provisioning")
  private Boolean provisioning;

  @SerializedName("snmp_community")
  private String snmpCommunity;

  @SerializedName("ntp_server_address")
  private String ntpServerAddress;

  @SerializedName("physical_ifs")
  private List<SpineNodePhysicalIfEntity> physicalIfList;

  @SerializedName("breakout_ifs")
  private List<SpineNodeBreakoutIfEntity> breakoutIfList;

  @SerializedName("internal_link_ifs")
  private List<InternalLinkIfEntity> internalLinkIfList;

  @SerializedName("lag_ifs")
  private List<SpineNodeLagIfEntity> lagIfList;

  @SerializedName("router_id")
  private String routerId;

  @SerializedName("management_if_address")
  private String managementIfAddress;

  @SerializedName("provisioning_status")
  private String provisioningStatus;

  public String getNodeId() {
    return nodeId;
  }

  public void setNodeId(String nodeId) {
    this.nodeId = nodeId;
  }

  public String getEquipmentTypeId() {
    return equipmentTypeId;
  }

  public void setEquipmentTypeId(String equipmentTypeId) {
    this.equipmentTypeId = equipmentTypeId;
  }

  public String getHostName() {
    return hostName;
  }

  public void setHostName(String hostName) {
    this.hostName = hostName;
  }

  public String getMacAddress() {
    return macAddress;
  }

  public void setMacAddress(String macAddress) {
    this.macAddress = macAddress;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public Boolean getProvisioning() {
    return provisioning;
  }

  public void setProvisioning(Boolean provisioning) {
    this.provisioning = provisioning;
  }

  public String getSnmpCommunity() {
    return snmpCommunity;
  }

  public void setSnmpCommunity(String snmpCommunity) {
    this.snmpCommunity = snmpCommunity;
  }

  public String getNtpServerAddress() {
    return ntpServerAddress;
  }

  public void setNtpServerAddress(String ntpServerAddress) {
    this.ntpServerAddress = ntpServerAddress;
  }

  public List<SpineNodePhysicalIfEntity> getPhysicalIfList() {
    return physicalIfList;
  }

  public void setPhysicalIfList(List<SpineNodePhysicalIfEntity> physicalIfList) {
    this.physicalIfList = physicalIfList;
  }

  public List<SpineNodeBreakoutIfEntity> getBreakoutIfList() {
    return breakoutIfList;
  }

  public void setBreakoutIfList(List<SpineNodeBreakoutIfEntity> breakoutIfList) {
    this.breakoutIfList = breakoutIfList;
  }

  public List<InternalLinkIfEntity> getInternalLinkIfList() {
    return internalLinkIfList;
  }

  public void setInternalLinkIfList(List<InternalLinkIfEntity> internalLinkIfList) {
    this.internalLinkIfList = internalLinkIfList;
  }

  public List<SpineNodeLagIfEntity> getLagIfList() {
    return lagIfList;
  }

  public void setLagIfList(List<SpineNodeLagIfEntity> lagIfList) {
    this.lagIfList = lagIfList;
  }

  public String getRouterId() {
    return routerId;
  }

  public void setRouterId(String routerId) {
    this.routerId = routerId;
  }

  public String getManagementIfAddress() {
    return managementIfAddress;
  }

  public void setManagementIfAddress(String managementIfAddress) {
    this.managementIfAddress = managementIfAddress;
  }

  public String getProvisioningStatus() {
    return provisioningStatus;
  }

  public void setProvisioningStatus(String provisioningStatus) {
    this.provisioningStatus = provisioningStatus;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

}
