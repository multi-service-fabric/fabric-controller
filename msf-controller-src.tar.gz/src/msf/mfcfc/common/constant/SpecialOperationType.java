
package msf.mfcfc.common.constant;

public enum SpecialOperationType {

  NORMAL,

  SPECIALOPERATION;
}
