
package msf.mfcfc.common.constant;

public enum OperationType {

  NORMAL,

  PRIORITY;

}
