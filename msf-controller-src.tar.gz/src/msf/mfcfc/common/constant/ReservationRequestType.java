
package msf.mfcfc.common.constant;

public enum ReservationRequestType {

  NORMAL,

  RESERVATION;
}
