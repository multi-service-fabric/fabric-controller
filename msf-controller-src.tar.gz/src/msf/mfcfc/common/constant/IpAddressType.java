package msf.mfcfc.common.constant;


public enum IpAddressType {

  
  IPV4,
  
  IPV4V6,
  
  IPV4V6FQDN;

}
