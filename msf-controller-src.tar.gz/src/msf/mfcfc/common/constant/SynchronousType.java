
package msf.mfcfc.common.constant;

public enum SynchronousType {

  SYNC,

  ASYNC;
}
