
package msf.mfcfc.common.constant;

public enum EcEmControlStatus {

  SUCCESS,

  FAILED,

  EM_SUCCESS_BUT_EC_FAILED;

  private EcEmControlStatus() {
  }
}
