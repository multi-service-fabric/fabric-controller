
package msf.mfcfc.common.constant;


public enum RestRequestType {

  
  NORMAL,
  
  NOTIFICATION;
}
