package msf.mfcfc.common.constant;


public enum OperationExecutionStatus {

  
  ALLOWED,

  
  NOT_ALLOWED;

}
