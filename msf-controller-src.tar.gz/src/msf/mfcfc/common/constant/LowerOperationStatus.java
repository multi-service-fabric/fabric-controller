package msf.mfcfc.common.constant;


public enum LowerOperationStatus {

  
  ALL_SUCCESS,
  
  ALL_FAILED,
  
  MIXED;
}
