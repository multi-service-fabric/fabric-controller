
package msf.mfcfc.common.constant;


public enum RequestType {

  
  REQUEST,
  
  ROLLBACK;
}
