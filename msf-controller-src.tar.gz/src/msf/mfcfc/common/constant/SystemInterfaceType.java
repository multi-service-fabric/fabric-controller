
package msf.mfcfc.common.constant;

public enum SystemInterfaceType {

  INTERNAL,

  EXTERNAL;

}
