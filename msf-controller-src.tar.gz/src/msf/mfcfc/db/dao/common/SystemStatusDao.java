
package msf.mfcfc.db.dao.common;

import msf.mfcfc.common.data.SystemStatus;
import msf.mfcfc.db.dao.AbstractCommonDao;

public abstract class SystemStatusDao extends AbstractCommonDao<SystemStatus, Integer> {

}
