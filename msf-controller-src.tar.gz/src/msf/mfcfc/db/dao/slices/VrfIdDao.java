
package msf.mfcfc.db.dao.slices;

import msf.mfcfc.common.data.VrfId;
import msf.mfcfc.db.dao.AbstractCommonDao;

public abstract class VrfIdDao extends AbstractCommonDao<VrfId, Integer> {

}
