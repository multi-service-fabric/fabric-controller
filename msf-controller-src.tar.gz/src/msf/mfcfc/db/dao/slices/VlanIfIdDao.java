
package msf.mfcfc.db.dao.slices;

import msf.mfcfc.common.data.VlanIfId;
import msf.mfcfc.db.dao.AbstractCommonDao;

public abstract class VlanIfIdDao extends AbstractCommonDao<VlanIfId, Long> {

}
