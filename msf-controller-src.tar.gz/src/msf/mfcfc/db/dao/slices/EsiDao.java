
package msf.mfcfc.db.dao.slices;

import msf.mfcfc.common.data.EsiId;
import msf.mfcfc.common.data.EsiIdPK;
import msf.mfcfc.db.dao.AbstractCommonDao;

public abstract class EsiDao extends AbstractCommonDao<EsiId, EsiIdPK> {
}
