
package msf.mfcfc.db.dao.slices;

import msf.mfcfc.common.data.SliceId;
import msf.mfcfc.db.dao.AbstractCommonDao;

public abstract class SliceIdDao extends AbstractCommonDao<SliceId, Integer> {

}
