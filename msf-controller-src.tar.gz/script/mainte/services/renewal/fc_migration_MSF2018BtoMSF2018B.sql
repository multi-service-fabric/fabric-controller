--
--
-- DDL for updating the DB schema definition version of FC from "2018B" to "2018B".
--
--

-- No change SQL