update system_status set renewal_status = 0 where system_id = 1;
