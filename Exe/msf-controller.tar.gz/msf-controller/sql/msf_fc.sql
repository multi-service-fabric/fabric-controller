CREATE DATABASE msf_fc;



DROP TABLE IF EXISTS async_requests;
DROP TABLE IF EXISTS bgp_connections;
DROP TABLE IF EXISTS boot_error_message;
DROP TABLE IF EXISTS cp_ids;
DROP TABLE IF EXISTS l2_cps;
DROP TABLE IF EXISTS l3_cp_bgp_options;
DROP TABLE IF EXISTS l3_cp_ospf_options;
DROP TABLE IF EXISTS l3_cp_static_route_options;
DROP TABLE IF EXISTS l3_cp_vrrp_options;
DROP TABLE IF EXISTS l3_cps;
DROP TABLE IF EXISTS edge_points;
DROP TABLE IF EXISTS equipment_ifs;
DROP TABLE IF EXISTS internal_link_ifs;
DROP TABLE IF EXISTS lag_constructions;
DROP TABLE IF EXISTS lag_ifs;
DROP TABLE IF EXISTS physical_ifs;
DROP TABLE IF EXISTS nodes;
DROP TABLE IF EXISTS equipments;
DROP TABLE IF EXISTS l2_slices;
DROP TABLE IF EXISTS l3_slices;
DROP TABLE IF EXISTS rrs;
DROP TABLE IF EXISTS slice_ids;
DROP TABLE IF EXISTS slice_manager_base_info;
DROP TABLE IF EXISTS sw_clusters;
DROP TABLE IF EXISTS system_status;
DROP TABLE IF EXISTS traffic_collect_interval;
DROP TABLE IF EXISTS traffic_history_l2slice;
DROP TABLE IF EXISTS traffic_history_l3slice;
DROP TABLE IF EXISTS vrf_ids;







CREATE TABLE async_requests
(
	operation_id text NOT NULL,
	occurred_time timestamp with time zone NOT NULL,
	last_update_time timestamp with time zone NOT NULL,

	status int NOT NULL,

	sub_status text,
	request_uri text,

	request_method varchar(6),
	request_body text,

	response_status_code int,
	response_body text,
	PRIMARY KEY (operation_id)
) WITHOUT OIDS;



CREATE TABLE bgp_connections
(
	sw_cluster_id text NOT NULL,

	node_info_id bigint NOT NULL,
	rr_node_id int NOT NULL,
	PRIMARY KEY (sw_cluster_id, node_info_id, rr_node_id)
) WITHOUT OIDS;



CREATE TABLE boot_error_message
(
	sw_cluster_id text NOT NULL,
	equipment_type_id int NOT NULL,
	boot_error_msg text NOT NULL,
	PRIMARY KEY (sw_cluster_id, equipment_type_id, boot_error_msg)
) WITHOUT OIDS;


CREATE TABLE cp_ids
(

	layer_type int NOT NULL,

	slice_id text NOT NULL,
	next_id int DEFAULT 1 NOT NULL,
	PRIMARY KEY (layer_type, slice_id)
) WITHOUT OIDS;



CREATE TABLE edge_points
(
	sw_cluster_id text NOT NULL,
	edge_point_id int NOT NULL,

	physical_if_info_id bigint,

	lag_if_info_id bigint,
	PRIMARY KEY (sw_cluster_id, edge_point_id)
) WITHOUT OIDS;


CREATE TABLE equipments
(
	sw_cluster_id text NOT NULL,
	equipment_type_id int NOT NULL,
	platform_name text NOT NULL,
	os_name text NOT NULL,
	firmware_version text NOT NULL,

	l2vpn_capability boolean NOT NULL,

	l3vpn_capability boolean NOT NULL,
	config_template text NOT NULL,
	initial_config text NOT NULL,
	boot_complete_msg text NOT NULL,
	PRIMARY KEY (sw_cluster_id, equipment_type_id)
) WITHOUT OIDS;



CREATE TABLE equipment_ifs
(
	sw_cluster_id text NOT NULL,
	equipment_type_id int NOT NULL,
	physical_if_id text NOT NULL,

	speed_capability varchar(8) NOT NULL,
	PRIMARY KEY (sw_cluster_id, equipment_type_id, physical_if_id, speed_capability)
) WITHOUT OIDS;



CREATE TABLE internal_link_ifs
(

	internal_link_if_id int NOT NULL,

	lag_if_info_id bigint NOT NULL UNIQUE,

	operation_status int NOT NULL,
	PRIMARY KEY (internal_link_if_id)
) WITHOUT OIDS;



CREATE TABLE l2_cps
(

	slice_id text NOT NULL,

	cp_id text NOT NULL,
	sw_cluster_id text NOT NULL,
	edge_point_id int NOT NULL,

	vlan_id int NOT NULL,

	status int DEFAULT 0 NOT NULL,

	reservation_status int DEFAULT 0 NOT NULL,

	operation_status int DEFAULT 0 NOT NULL,

	port_mode int NOT NULL,
	PRIMARY KEY (slice_id, cp_id)
) WITHOUT OIDS;



CREATE TABLE l2_slices
(

	slice_id text NOT NULL,

	vrf_id int NOT NULL UNIQUE,

	status int DEFAULT 0 NOT NULL,

	reservation_status int DEFAULT 0 NOT NULL,
	PRIMARY KEY (slice_id)
) WITHOUT OIDS;



CREATE TABLE l3_cps
(

	slice_id text NOT NULL,

	cp_id text NOT NULL,
	sw_cluster_id text NOT NULL,
	edge_point_id int NOT NULL,

	vlan_id int NOT NULL,

	status int DEFAULT 0 NOT NULL,

	reservation_status int DEFAULT 0 NOT NULL,

	operation_status int DEFAULT 0 NOT NULL,

	ipv4_address varchar(15),

	ipv4_prefix int,

	ipv6_address varchar(39),

	ipv6_prefix int,
	mtu int NOT NULL,
	PRIMARY KEY (slice_id, cp_id),
	CONSTRAINT slice_ipv4_address UNIQUE (slice_id, ipv4_address),
	CONSTRAINT slice_ipv6_address UNIQUE (slice_id, ipv6_address)
) WITHOUT OIDS;



CREATE TABLE l3_cp_bgp_options
(

	slice_id text NOT NULL,

	cp_id text NOT NULL,

	role int NOT NULL,
	neighbor_as int NOT NULL,

	neighbor_ipv4_address varchar(15),

	neighbor_ipv6_address varchar(39),
	PRIMARY KEY (slice_id, cp_id)
) WITHOUT OIDS;



CREATE TABLE l3_cp_ospf_options
(

	slice_id text NOT NULL,

	cp_id text NOT NULL,
	metric int NOT NULL,
	PRIMARY KEY (slice_id, cp_id)
) WITHOUT OIDS;



CREATE TABLE l3_cp_static_route_options
(

	slice_id text NOT NULL,

	cp_id text NOT NULL,

	address_type int NOT NULL,

	destination_address varchar(39) NOT NULL,

	prefix int NOT NULL,

	nexthop_address varchar(39) NOT NULL,
	PRIMARY KEY (slice_id, cp_id, address_type, destination_address, prefix, nexthop_address)
) WITHOUT OIDS;



CREATE TABLE l3_cp_vrrp_options
(

	slice_id text NOT NULL,

	cp_id text NOT NULL,
	group_id int NOT NULL,

	role int NOT NULL,

	virtual_ipv4_address varchar(15),

	virtual_ipv6_address varchar(39),
	PRIMARY KEY (slice_id, cp_id)
) WITHOUT OIDS;



CREATE TABLE l3_slices
(

	slice_id text NOT NULL,

	vrf_id int NOT NULL UNIQUE,

	plane int NOT NULL,

	status int DEFAULT 0 NOT NULL,

	reservation_status int DEFAULT 0 NOT NULL,
	PRIMARY KEY (slice_id)
) WITHOUT OIDS;



CREATE TABLE lag_constructions
(

	physical_if_info_id bigint NOT NULL,

	lag_if_info_id bigint NOT NULL,
	PRIMARY KEY (physical_if_info_id)
) WITHOUT OIDS;



CREATE TABLE lag_ifs
(

	lag_if_info_id bigserial NOT NULL,

	node_info_id bigint NOT NULL,
	lag_if_id int NOT NULL,

	ipv4_address varchar(15),

	opposite_node_info_id bigint,

	opposite_lag_if_id int,

	minimum_links int NOT NULL,

	speed varchar(8),
	PRIMARY KEY (lag_if_info_id),
	CONSTRAINT lag_id UNIQUE (node_info_id, lag_if_id),
	CONSTRAINT opposite_lag_id UNIQUE (opposite_node_info_id, opposite_lag_if_id)
) WITHOUT OIDS;



CREATE TABLE nodes
(

	node_info_id bigserial NOT NULL,
	sw_cluster_id text NOT NULL,

	node_type int NOT NULL,
	node_id int NOT NULL,
	equipment_type_id int NOT NULL,
	provisioning boolean NOT NULL,

	rp_flag boolean,

	plane int,

	vpn_type varchar(2),
	username text NOT NULL,
	passward text NOT NULL,

	router_id text NOT NULL,
	management_if_address text NOT NULL,
	snmp_community text NOT NULL,
	ntp_server_address text NOT NULL,

	provisioning_status int NOT NULL,
	host_name text NOT NULL,

	mac_addr varchar(17) NOT NULL UNIQUE,
	PRIMARY KEY (node_info_id),
	CONSTRAINT device_id UNIQUE (sw_cluster_id, node_type, node_id)
) WITHOUT OIDS;



CREATE TABLE physical_ifs
(

	physical_if_info_id bigserial NOT NULL,

	node_info_id bigint NOT NULL,
	physical_if_id text NOT NULL,

	opposite_node_info_id bigint,

	opposite_physical_if_id text,

	physical_port_flag boolean NOT NULL,
	speed varchar(8),
	PRIMARY KEY (physical_if_info_id),
	CONSTRAINT if_id UNIQUE (node_info_id, physical_if_id),
	CONSTRAINT opposite_if_id UNIQUE (opposite_node_info_id, opposite_physical_if_id)
) WITHOUT OIDS;



CREATE TABLE rrs
(
	sw_cluster_id text NOT NULL,
	rr_node_id int NOT NULL,
	rr_router_id text NOT NULL UNIQUE,
	PRIMARY KEY (sw_cluster_id, rr_node_id)
) WITHOUT OIDS;



CREATE TABLE slice_ids
(

	layer_type int NOT NULL,
	next_id int DEFAULT 1 NOT NULL,
	PRIMARY KEY (layer_type)
) WITHOUT OIDS;



CREATE TABLE slice_manager_base_info
(

	base_id int NOT NULL,

	l2vpn_multicast_address_base text,
	PRIMARY KEY (base_id)
) WITHOUT OIDS;



CREATE TABLE sw_clusters
(
	sw_cluster_id text NOT NULL,
	max_leaf_num int NOT NULL,
	max_spine_num int NOT NULL,

	ec_control_address text NOT NULL,
	ec_control_port int NOT NULL,
	as_num int NOT NULL,

	rp_loopback_address varchar(15) NOT NULL,
	interface_start_address varchar(15) NOT NULL,
	loopback_start_address varchar(15) NOT NULL,
	management_start_address varchar(15) NOT NULL,
	management_address_prefix int NOT NULL,
	PRIMARY KEY (sw_cluster_id)
) WITHOUT OIDS;



CREATE TABLE system_status
(

	system_id int NOT NULL,

	service_status int NOT NULL,

	blockade_status int NOT NULL,
	PRIMARY KEY (system_id)
) WITHOUT OIDS;



CREATE TABLE traffic_collect_interval
(

	start_time timestamp NOT NULL,

	end_time timestamp,

	interval int NOT NULL,
	PRIMARY KEY (start_time)
) WITHOUT OIDS;



CREATE TABLE traffic_history_l2slice
(

	occurred_time timestamp with time zone NOT NULL,

	start_cluster_id text NOT NULL,

	start_leaf_node_id int NOT NULL,

	start_edge_point_id int NOT NULL,

	end_cluster_id text NOT NULL,

	end_leaf_node_id int NOT NULL,

	end_edge_point_id int NOT NULL,

	value float NOT NULL,
	PRIMARY KEY (occurred_time, start_cluster_id, start_leaf_node_id, start_edge_point_id, end_cluster_id, end_leaf_node_id, end_edge_point_id)
) WITHOUT OIDS;



CREATE TABLE traffic_history_l3slice
(

	occurred_time timestamp with time zone NOT NULL,

	slice_id text NOT NULL,

	start_cluster_id text NOT NULL,

	start_leaf_node_id int NOT NULL,

	start_cp_id text NOT NULL,

	end_cluster_id text NOT NULL,

	end_leaf_node_id int NOT NULL,

	end_cp_id text NOT NULL,

	value float NOT NULL,
	PRIMARY KEY (occurred_time, slice_id, start_cluster_id, start_leaf_node_id, start_cp_id, end_cluster_id, end_leaf_node_id, end_cp_id)
) WITHOUT OIDS;



CREATE TABLE vrf_ids
(

	layer_type int NOT NULL,
	next_id int DEFAULT 1 NOT NULL,
	PRIMARY KEY (layer_type)
) WITHOUT OIDS;





ALTER TABLE l2_cps
	ADD FOREIGN KEY (sw_cluster_id, edge_point_id)
	REFERENCES edge_points (sw_cluster_id, edge_point_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE l3_cps
	ADD FOREIGN KEY (sw_cluster_id, edge_point_id)
	REFERENCES edge_points (sw_cluster_id, edge_point_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE boot_error_message
	ADD FOREIGN KEY (sw_cluster_id, equipment_type_id)
	REFERENCES equipments (sw_cluster_id, equipment_type_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE equipment_ifs
	ADD FOREIGN KEY (sw_cluster_id, equipment_type_id)
	REFERENCES equipments (sw_cluster_id, equipment_type_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE nodes
	ADD FOREIGN KEY (sw_cluster_id, equipment_type_id)
	REFERENCES equipments (sw_cluster_id, equipment_type_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE l2_cps
	ADD FOREIGN KEY (slice_id)
	REFERENCES l2_slices (slice_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE l3_cp_bgp_options
	ADD FOREIGN KEY (slice_id, cp_id)
	REFERENCES l3_cps (slice_id, cp_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE l3_cp_ospf_options
	ADD FOREIGN KEY (slice_id, cp_id)
	REFERENCES l3_cps (slice_id, cp_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE l3_cp_static_route_options
	ADD FOREIGN KEY (slice_id, cp_id)
	REFERENCES l3_cps (slice_id, cp_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE l3_cp_vrrp_options
	ADD FOREIGN KEY (slice_id, cp_id)
	REFERENCES l3_cps (slice_id, cp_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE l3_cps
	ADD FOREIGN KEY (slice_id)
	REFERENCES l3_slices (slice_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE internal_link_ifs
	ADD FOREIGN KEY (lag_if_info_id)
	REFERENCES lag_ifs (lag_if_info_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE lag_constructions
	ADD FOREIGN KEY (lag_if_info_id)
	REFERENCES lag_ifs (lag_if_info_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE bgp_connections
	ADD FOREIGN KEY (node_info_id)
	REFERENCES nodes (node_info_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE lag_ifs
	ADD FOREIGN KEY (node_info_id)
	REFERENCES nodes (node_info_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE lag_ifs
	ADD FOREIGN KEY (opposite_node_info_id)
	REFERENCES nodes (node_info_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE physical_ifs
	ADD FOREIGN KEY (node_info_id)
	REFERENCES nodes (node_info_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE physical_ifs
	ADD FOREIGN KEY (opposite_node_info_id)
	REFERENCES nodes (node_info_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE lag_constructions
	ADD FOREIGN KEY (physical_if_info_id)
	REFERENCES physical_ifs (physical_if_info_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE bgp_connections
	ADD FOREIGN KEY (sw_cluster_id, rr_node_id)
	REFERENCES rrs (sw_cluster_id, rr_node_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE edge_points
	ADD FOREIGN KEY (sw_cluster_id)
	REFERENCES sw_clusters (sw_cluster_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE equipments
	ADD FOREIGN KEY (sw_cluster_id)
	REFERENCES sw_clusters (sw_cluster_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE rrs
	ADD FOREIGN KEY (sw_cluster_id)
	REFERENCES sw_clusters (sw_cluster_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;



/* Comments */

COMMENT ON TABLE async_requests IS '非同期リクエストの情報を保持するテーブル。';
COMMENT ON COLUMN async_requests.status IS '0：未実行
100：実行中
200：完了
400：失敗
500：実行取消(未実行のままキャンセル)';
COMMENT ON COLUMN async_requests.sub_status IS '各機能が必要に応じて、「実行状態："実行中"」におけるさらに詳細なサブ状態を格納する。';
COMMENT ON COLUMN async_requests.request_method IS 'POST/PUT/DELETE/GET';
COMMENT ON COLUMN async_requests.response_status_code IS 'REST(HTTP)の応答コードと同じポリシーにて値を設定
例：200 = OK';
COMMENT ON TABLE bgp_connections IS 'RRと装置(Leaf)のBGP接続関係を示すテーブル。';
COMMENT ON COLUMN bgp_connections.node_info_id IS 'サロゲートキー
オートインクリメント(cycle)';
COMMENT ON TABLE boot_error_message IS 'ゼロタッチプロビジョニング時の起動失敗メッセージを保持するテーブル。
起動失敗判定メッセージは各機種に対して複数設定されるため、各機種情報の起動失敗判定メッセージ毎にレコードを保持する。';
COMMENT ON TABLE cp_ids IS 'CP IDの払出し情報のテーブル。';
COMMENT ON COLUMN cp_ids.layer_type IS '2 : L2
3 : L3';
COMMENT ON COLUMN cp_ids.slice_id IS 'L2またはL3スライスID';
COMMENT ON TABLE edge_points IS 'edge-pointの情報を保持するテーブル。';
COMMENT ON COLUMN edge_points.physical_if_info_id IS 'lag_if_idといずれか一方のみを指定';
COMMENT ON COLUMN edge_points.lag_if_info_id IS 'physical_if_idといずれか一方のみを指定';
COMMENT ON TABLE equipments IS '機種毎の固有情報を保持するテーブル。
機種情報をFC/ECそれぞれで分けて保持するため、SWクラスタ増設時を考慮し、SWクラスタ毎の機種情報を管理する。';
COMMENT ON COLUMN equipments.l2vpn_capability IS 'L2VPN対応可否';
COMMENT ON COLUMN equipments.l3vpn_capability IS 'L3VPN対応可否';
COMMENT ON TABLE equipment_ifs IS '機種毎のポートおよび取り得る速度を保持するテーブル。';
COMMENT ON COLUMN equipment_ifs.speed_capability IS '(例)
10G';
COMMENT ON TABLE internal_link_ifs IS '内部リンクを示すテーブル。';
COMMENT ON COLUMN internal_link_ifs.internal_link_if_id IS 'lag_if_info_idと同じ値';
COMMENT ON COLUMN internal_link_ifs.lag_if_info_id IS 'サロゲートキー
オートインクリメント(cycle)';
COMMENT ON COLUMN internal_link_ifs.operation_status IS 'IFの状態

1 : up

2 : down
';
COMMENT ON TABLE l2_cps IS 'L2CPの情報を保持するテーブル。';
COMMENT ON COLUMN l2_cps.slice_id IS 'MSFコントローラ全体で一意なL2スライスのID';
COMMENT ON COLUMN l2_cps.cp_id IS 'L2スライス毎に一意なL2 CPのID';
COMMENT ON COLUMN l2_cps.vlan_id IS 'L2 CP向けVLAN ID
1～4096';
COMMENT ON COLUMN l2_cps.status IS '0 : 無効

1 : 有効';
COMMENT ON COLUMN l2_cps.reservation_status IS 'CPの変更予約状態
0 : 予約無し

1 : 有効化予約

2 : 無効化予約';
COMMENT ON COLUMN l2_cps.operation_status IS 'CPによって作成されたIFの状態
0 : unknown (無効状態もこの状態を設定とする)
1 : up
2 : down';
COMMENT ON COLUMN l2_cps.port_mode IS 'VLANのポートモード
1 : access
2 : trunk';
COMMENT ON TABLE l2_slices IS 'L2スライスの情報を保持するテーブル。';
COMMENT ON COLUMN l2_slices.slice_id IS 'MSFコントローラ全体で一意なL2スライスのID';
COMMENT ON COLUMN l2_slices.vrf_id IS '装置に利用設定するスライス毎に一意な情報';
COMMENT ON COLUMN l2_slices.status IS '0 : 無効
1 : 有効';
COMMENT ON COLUMN l2_slices.reservation_status IS 'スライスの変更予約状態
0 : 予約無し
1 : 有効化予約
2 : 無効化予約';
COMMENT ON TABLE l3_cps IS 'L3CPの情報を保持するテーブル。';
COMMENT ON COLUMN l3_cps.slice_id IS 'MSFコントローラ全体で一意なL3スライスのID';
COMMENT ON COLUMN l3_cps.cp_id IS 'L3スライス毎に一意なL3 CPのID';
COMMENT ON COLUMN l3_cps.vlan_id IS '0～4096
0の場合にはVLANタグは付与しない。';
COMMENT ON COLUMN l3_cps.status IS '0 : 無効


1 : 有効';
COMMENT ON COLUMN l3_cps.reservation_status IS 'CPの変更予約状態

0 : 予約無し

1 : 有効化予約

2 : 無効化予約';
COMMENT ON COLUMN l3_cps.operation_status IS 'CPによって作成されたIFの状態

0 : unknown (無効状態もこの状態を設定とする)

1 : up

2 : down
';
COMMENT ON COLUMN l3_cps.ipv4_address IS 'IPv6アドレスと少なくとも一方は設定する';
COMMENT ON COLUMN l3_cps.ipv4_prefix IS 'IPv4アドレス設定時は必ず指定
1～31';
COMMENT ON COLUMN l3_cps.ipv6_address IS 'IPv4アドレスと少なくとも一方は設定する';
COMMENT ON COLUMN l3_cps.ipv6_prefix IS 'IPv6アドレス設定時は必ず指定
1～127';
COMMENT ON TABLE l3_cp_bgp_options IS 'L3CPのBGPオプション情報を保持するテーブル。';
COMMENT ON COLUMN l3_cp_bgp_options.slice_id IS 'MSFコントローラ全体で一意なL3スライスのID';
COMMENT ON COLUMN l3_cp_bgp_options.cp_id IS 'L3スライス毎に一意なL3 CPのID';
COMMENT ON COLUMN l3_cp_bgp_options.role IS '1 : master
2 : slave';
COMMENT ON COLUMN l3_cp_bgp_options.neighbor_ipv4_address IS '対応するL3CP情報にIPv4アドレスが設定されている場合、かつBGPとして利用する場合指定する。';
COMMENT ON COLUMN l3_cp_bgp_options.neighbor_ipv6_address IS '対応するL3CP情報にIPv6アドレスが設定されている場合、かつBGPとして利用する場合指定する。';
COMMENT ON TABLE l3_cp_ospf_options IS 'L3CPのOSPFオプション情報を保持するテーブル。';
COMMENT ON COLUMN l3_cp_ospf_options.slice_id IS 'MSFコントローラ全体で一意なL3スライスのID';
COMMENT ON COLUMN l3_cp_ospf_options.cp_id IS 'L3スライス毎に一意なL3 CPのID';
COMMENT ON TABLE l3_cp_static_route_options IS 'L3CPのstatic経路オプション情報を保持するテーブル。';
COMMENT ON COLUMN l3_cp_static_route_options.slice_id IS 'MSFコントローラ全体で一意なL3スライスのID';
COMMENT ON COLUMN l3_cp_static_route_options.cp_id IS 'L3スライス毎に一意なL3 CPのID';
COMMENT ON COLUMN l3_cp_static_route_options.address_type IS 'static経路のアドレス種別
4 : IPv4
6 : IPv6';
COMMENT ON COLUMN l3_cp_static_route_options.destination_address IS '宛先のホスト/ネットワークのアドレス
アドレス種別に応じたフォーマットのデータを格納する';
COMMENT ON COLUMN l3_cp_static_route_options.prefix IS '宛先ネットワークに対するアドレス
アドレス種別に応じた値が格納される
1～32 (IPv4)
1～128 (IPv6)';
COMMENT ON COLUMN l3_cp_static_route_options.nexthop_address IS '宛先アドレスに到達するためのネクストホップアドレス
アドレス種別に応じたフォーマットの情報を格納する';
COMMENT ON TABLE l3_cp_vrrp_options IS 'L3CPのVRRPオプション情報を保持するテーブル。';
COMMENT ON COLUMN l3_cp_vrrp_options.slice_id IS 'MSFコントローラ全体で一意なL3スライスのID';
COMMENT ON COLUMN l3_cp_vrrp_options.cp_id IS 'L3スライス毎に一意なL3 CPのID';
COMMENT ON COLUMN l3_cp_vrrp_options.role IS '1 : master

2 : slave';
COMMENT ON COLUMN l3_cp_vrrp_options.virtual_ipv4_address IS '対応するL3CP情報にIPv4アドレスが設定されている場合、かつVRRPとして利用する場合指定する。';
COMMENT ON COLUMN l3_cp_vrrp_options.virtual_ipv6_address IS '対応するL3CP情報にIPv6アドレスが設定されている場合、かつVRRPとして利用する場合指定する。';
COMMENT ON TABLE l3_slices IS 'L3スライスの情報を保持するテーブル。';
COMMENT ON COLUMN l3_slices.slice_id IS 'MSFコントローラ全体で一意なL3スライスのID';
COMMENT ON COLUMN l3_slices.vrf_id IS '装置に利用設定するスライス毎に一意な情報';
COMMENT ON COLUMN l3_slices.plane IS '1 : A面
2 : B面';
COMMENT ON COLUMN l3_slices.status IS '0 : 無効

1 : 有効';
COMMENT ON COLUMN l3_slices.reservation_status IS 'スライスの変更予約状態

0 : 予約無し

1 : 有効化予約

2 : 無効化予約';
COMMENT ON TABLE lag_constructions IS 'LAGを構成する物理IFの関係を示すテーブル。';
COMMENT ON COLUMN lag_constructions.physical_if_info_id IS ' ';
COMMENT ON COLUMN lag_constructions.lag_if_info_id IS 'サロゲートキー
オートインクリメント(cycle)';
COMMENT ON TABLE lag_ifs IS '装置のLAG IFに関する情報を保持するテーブル。';
COMMENT ON COLUMN lag_ifs.lag_if_info_id IS 'サロゲートキー
オートインクリメント(cycle)';
COMMENT ON COLUMN lag_ifs.node_info_id IS ' ';
COMMENT ON COLUMN lag_ifs.ipv4_address IS '内部リンク向けに利用する場合にのみ設定する。
IPv4形式 (X.X.X.X)';
COMMENT ON COLUMN lag_ifs.opposite_node_info_id IS '対向装置を一意に識別するためのID
内部リンクの場合にのみ設定';
COMMENT ON COLUMN lag_ifs.opposite_lag_if_id IS '対向装置のLagIFを一意に識別するためのID
内部リンクの場合にのみ設定';
COMMENT ON COLUMN lag_ifs.minimum_links IS 'LagIFのリンクダウンを判断するための条件パラメータ';
COMMENT ON COLUMN lag_ifs.speed IS '物理IFの速度
(例)
10G';
COMMENT ON TABLE nodes IS '装置(Spine、Leaf)の個別情報を保持するテーブル。';
COMMENT ON COLUMN nodes.node_info_id IS 'サロゲートキー
オートインクリメント(cycle)';
COMMENT ON COLUMN nodes.node_type IS '1:Leaf
2:Spine';
COMMENT ON COLUMN nodes.rp_flag IS 'Spineの場合のみ
RPであるかどうかを示すフラグ';
COMMENT ON COLUMN nodes.plane IS '1: "A面"
2: "B面"
Leafのみ';
COMMENT ON COLUMN nodes.vpn_type IS '"l2","l3"のいずれか

Leafのみ';
COMMENT ON COLUMN nodes.router_id IS '自動計算(ループバックアドレス)';
COMMENT ON COLUMN nodes.provisioning_status IS '0:未起動
1:起動(未設定)
2:装置設定中
3:増設失敗
4:増設完了';
COMMENT ON COLUMN nodes.mac_addr IS 'XX:XX:XX:XX:XX:XXの形式';
COMMENT ON TABLE physical_ifs IS '装置の物理IFに関する情報を保持するテーブル。';
COMMENT ON COLUMN physical_ifs.physical_if_info_id IS 'サロゲートキー
オートインクリメント(cycle)';
COMMENT ON COLUMN physical_ifs.node_info_id IS ' ';
COMMENT ON COLUMN physical_ifs.opposite_node_info_id IS '対向装置を一意に識別するためのID
内部リンクの場合にのみ設定';
COMMENT ON COLUMN physical_ifs.opposite_physical_if_id IS '対向装置のポートを一意に識別するためのID
内部リンクの場合にのみ設定';
COMMENT ON COLUMN physical_ifs.physical_port_flag IS '物理ポート登録されたIFのフラグ
trueの場合、内部リンクとして使ってはいけないIFの定義';
COMMENT ON TABLE rrs IS 'RRを示すテーブル。';
COMMENT ON TABLE slice_ids IS 'スライスIDの払出し情報のテーブル。';
COMMENT ON COLUMN slice_ids.layer_type IS '2 : L2
3 : L3';
COMMENT ON TABLE slice_manager_base_info IS 'スライス管理の基本情報を保持するテーブル。
レコードは1件のみ(base_id=1)しか許容しない。';
COMMENT ON COLUMN slice_manager_base_info.base_id IS '自システムを示す"1"のみを利用する';
COMMENT ON COLUMN slice_manager_base_info.l2vpn_multicast_address_base IS 'L2VPN作成時に用いる。';
COMMENT ON TABLE sw_clusters IS 'SWクラスタ固有の情報を保持するテーブル。';
COMMENT ON COLUMN sw_clusters.ec_control_address IS '兼 装置のSNMPサーバアドレス';
COMMENT ON COLUMN sw_clusters.rp_loopback_address IS 'Spine登録時のPIM設定(other-rp-address)に用いる';
COMMENT ON TABLE system_status IS 'システム状態を系間で引き継ぐための管理テーブル。
レコードは1件のみ(system_id=1)しか許容しない。';
COMMENT ON COLUMN system_status.system_id IS '自システムを示す"1"のみを利用する';
COMMENT ON COLUMN system_status.service_status IS '0：停止
10：起動準備中
50：系切替中
90：停止準備中
100：起動';
COMMENT ON COLUMN system_status.blockade_status IS '0：閉塞なし
1：閉塞あり';
COMMENT ON TABLE traffic_collect_interval IS 'トラヒックの収集間隔を記録しておくためのテーブル。';
COMMENT ON COLUMN traffic_collect_interval.start_time IS '本レコードの収集周期での収集が開始した時刻。';
COMMENT ON COLUMN traffic_collect_interval.end_time IS '本レコードの収集周期での収集が終了した時刻。
この収集周期で収集中の場合は、NULL値を格納する。';
COMMENT ON COLUMN traffic_collect_interval.interval IS 'FCがECからトラヒック収集値を収集する周期。';
COMMENT ON TABLE traffic_history_l2slice IS 'スライス種別がL2のスライス上で発生したトラヒックの履歴情報を格納するテーブル。
他テーブルのレコード削除が行われた場合でも、本テーブルのレコードは履歴情報として残す必要があるため、外部キーは設定しない。';
COMMENT ON COLUMN traffic_history_l2slice.occurred_time IS 'FCがECからトラヒック情報を収集した時刻。';
COMMENT ON COLUMN traffic_history_l2slice.start_cluster_id IS 'トラヒックの始点となるクラスタのクラスタID。';
COMMENT ON COLUMN traffic_history_l2slice.start_leaf_node_id IS 'トラヒックの始点となるLeafを一意に特定するための装置ID。';
COMMENT ON COLUMN traffic_history_l2slice.start_edge_point_id IS 'トラヒックの始点となるedge-pointを一意に特定するためのID。';
COMMENT ON COLUMN traffic_history_l2slice.end_cluster_id IS 'トラヒックの終点となるクラスタのクラスタID。';
COMMENT ON COLUMN traffic_history_l2slice.end_leaf_node_id IS 'トラヒックの終点となるLeafを一意に特定するための装置ID。';
COMMENT ON COLUMN traffic_history_l2slice.end_edge_point_id IS 'トラヒックの終点となるedge-pointを一意に特定するためのID。';
COMMENT ON COLUMN traffic_history_l2slice.value IS '始点-終点間で発生したトラヒック量(単位：Gbps)。
TM推定未実施の場合、値「-1.0」を格納する。';
COMMENT ON TABLE traffic_history_l3slice IS 'スライス種別がL3のスライス上で発生したトラヒックの履歴情報を格納するテーブル。
他テーブルのレコード削除が行われた場合でも、本テーブルのレコードは履歴情報として残す必要があるため、外部キーは設定しない。';
COMMENT ON COLUMN traffic_history_l3slice.occurred_time IS 'FCがECからトラヒック情報を収集した時刻。';
COMMENT ON COLUMN traffic_history_l3slice.slice_id IS '本トラヒックの発生したスライスのスライスID。';
COMMENT ON COLUMN traffic_history_l3slice.start_cluster_id IS 'トラヒックの始点となるクラスタのクラスタID。';
COMMENT ON COLUMN traffic_history_l3slice.start_leaf_node_id IS 'トラヒックの始点となるLeafを一意に特定するための装置ID。';
COMMENT ON COLUMN traffic_history_l3slice.start_cp_id IS 'トラヒックの始点となるCPを一意に特定するためのID。';
COMMENT ON COLUMN traffic_history_l3slice.end_cluster_id IS 'トラヒックの終点となるクラスタのクラスタID。';
COMMENT ON COLUMN traffic_history_l3slice.end_leaf_node_id IS 'トラヒックの終点となるLeaf装置ID';
COMMENT ON COLUMN traffic_history_l3slice.end_cp_id IS 'トラヒックの終点となるCPを一意に特定するためのID。';
COMMENT ON COLUMN traffic_history_l3slice.value IS '始点-終点間で発生したトラヒック量(単位：Gbps)。
TM推定未実施の場合、値「-1.0」を格納する。';
COMMENT ON TABLE vrf_ids IS 'VRF IDの払出し情報のテーブル。';
COMMENT ON COLUMN vrf_ids.layer_type IS '2 : L2
3 : L3';
